<html>
<body background="dates3.jpg">
<?php
$id=$_GET['id'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "court system";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql="select * from judge where jid=".$id;
$result=mysqli_query($conn,$sql);
//var_dump($result);
while($row=mysqli_fetch_assoc($result))
{
	echo "<h1 align='center'><B><I><font size=450px>DETAILS</font></I></B><h1><br>";
	echo "<br><br><br><table border='4' align='center' style='border-collapse: collapse'><tr>";
        echo "<td>JUDGE NAME:</td> <TD>" . $row["jname"]. "</TD></TR><TR><TD>DOB:</td> <TD> " . $row["dob"]. " </TD></TR></table><br><table border='4' align='center'><TR><TD>DATE OF JOINING: </td> <TD>". $row["doj"]." </TD></TR><TR><TD> ADDRESS: </td> <TD>". $row["jaddress"].  " </TD></TR></table><br><table border='4' align='center'><TR><TD>EMAIL ID: </td> <TD>". $row["eid"]. " </TD></TR><TR><TD>NO OF CASES JUDGED: </td> <TD>". $row["casejudged"]."</td></tr></table><br>";
		echo "<table border='4' align='center'><tr><td>DATE OF RETIREMENT:</td> <TD>" . $row["dor"]. "</td></tr></table>";

}

?>
</body>
</html>