<html>
<body background="back3.jpg">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "court system";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$rr=$_POST["ca"];
$gg=$_POST["all"];
if($gg=="ALL DATES"){
$sql = "SELECT caseno,alldate FROM casedate";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	echo "<h1 align='center'><B><I><font size=450px>ALL PREVIOUS HEARING DATES</font></I></B><h1><br>"; 
    while($row = $result->fetch_assoc()) {
		if($rr==$row["caseno"])
		{       
			echo "<table border='4' align='center'><tr><td> DATE:</td> <TD>" . $row["alldate"]. "</td></tr></table>";
		}
    }
} else {
    echo "0 results";
}
}
if($gg=="NEXT DATE"){
$sq="SELECT caseno,hdate from cases";
$resul = $conn->query($sq);

if ($resul->num_rows > 0) {
    // output data of each row
	 
    while($row = $resul->fetch_assoc()) {
		if($rr==$row["caseno"])
		{       echo "<h1 align='center'><B><I><font size=450px>NEXT HEARING DATE</font></I></B><h1><br>";
			echo "<table border='4' align='center'><tr><td>NEXT HEARING DATE:</td> <TD>" . $row["hdate"]. "</td></tr></table>";
		}
    }
} else {
    echo "0 results";
}
}
}
mysqli_close($conn);




//header("location: select data.php");
?>
</body>
</html>