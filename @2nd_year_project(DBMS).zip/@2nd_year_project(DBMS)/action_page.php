<html>
<head><style>
body {
    background-image: url("back6.jpg");
 background-repeat: no-repeat;
background-size:cover;
background-position:center center;
}
</style></head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "court system";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$rr=$_POST["uname"];
$hh=$_POST["psw"];

$gg=$_POST["m1"];
if($gg=="LAWYER"){
	
$sql = "SELECT * FROM lawyer";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
	
    // output data of each row
	 
    while($row = $result->fetch_assoc()) {
		if($hh==$row["passl"])
		{
			echo "<p align='right'><h2><B>GOOD MORNING!   " . $row["lname"]. "</B></h2></p>";
                        echo "<br><br><br><table border='4'color='blue' align='center' style='border-collapse:�collapse'><tr>";
        echo "<td>NAME:</td> <TD>" . $row["lname"]. "</TD></TR><TR><TD>DOB:</td> <TD> " . $row["dob"]. " </TD></TR></table><br><table border='4' align='center'><TR><TD>CONTACT NO: </td> <TD>". $row["contact"]." </TD></TR><TR><TD>ADDRESS: </td> <TD>". $row["laddress"]."</td></tr></table><br>";
		echo "<table border='4' align='center'><tr><td>EMAIL ID</td> <TD>" . $row["eid"]. "</td></tr>

<tr><td>CASE TYPE:</td> <TD>" . $row["type"]. "</td></tr>
<tr><td>NO OF CASES UNDERTAKEN:</td> <TD>" . $row["fought"]. "</td></tr>
<tr><td>NO OF CASES WON:</td> <TD>" . $row["won"]. "</td></tr>
<tr><td>NO OF CASES PENDING</td> <TD>" . $row["pending"]. "</td></tr>
</table>";
		}
    }
} else {
    echo "0 results";
}
}
if($gg=="JUDGE"){
$sq="SELECT * from judge";
$resul = $conn->query($sq);

if ($resul->num_rows > 0) {
    // output data of each row
	 
    while($row = $resul->fetch_assoc()) {
		if($hh==$row["pass"])
		{
		  echo "<p align='right'><h2><B>GOOD MORNING!   " . $row["jname"]. "</B></h2></p>";
                        echo "<br><br><br><table border='4'color='blue' align='center' style='border-collapse:�collapse'><tr>";
        echo "<td>NAME:</td> <TD>" . $row["jname"]. "</TD></TR><TR><TD>DOB:</td> <TD> " . $row["dob"]. " </TD></TR></table><br><table border='4' align='center'><TR><TD>DATE OF JOINING: </td> <TD>". $row["doj"]." </TD></TR><TR><TD>ADDRESS: </td> <TD>". $row["jaddress"]."</td></tr></table><br>";
		echo "<table border='4' align='center'><tr><td>EMAI ID</td> <TD>" . $row["eid"]. "</td></tr>

<tr><td>CASES JUDGED:</td> <TD>" . $row["casejudged"]. "</td></tr>
<tr><td>DATE OF RETIREMENT:</td> <TD>" . $row["dor"]. "</td></tr>
</table>";
		}
    }
} else {
    echo "0 results";
}
}
}
mysqli_close($conn);




//header("location: select data.php");
?>
</body>
</html>