<?php
$server = 'localhost'; 
$username   = 'root'; 
$password   = ''; 
$database   = 'shoping';  
$con=mysqli_connect($server,$username,$password,$database);
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  $sql = "SELECT
              name,
              product
          FROM
              user,purchase
where user.uname=purchase.uname";
  echo"<h2>VALIDATION OF PHP CODES</h2><br>";
 //var_dump($sql);
  $result = mysqli_query($con,$sql);
  //var_dump($result);

  if(!$result)
  {
      echo 'Mysql Error' . mysqli_error($con);
  }
  else
  {
      if(mysqli_num_rows($result) == 0)
      {
        //echo mysqli_num_rows($result);
          echo 'Nothing avaliable';
      }
      else
      {
        //prepare the table
                  echo '<table border="1">
                        <tr>
                          <th>Name</th>
                          <th>product</th>
                          
                        </tr>';

                  while($row = mysqli_fetch_assoc($result))
                  {
                      echo '<tr>';
                          echo '<td>';
                              echo  $row['name'];
                          echo '</td>';
                          echo '<td>';
                              echo $row['product'];
                          echo '</td>';
                          
                      echo '</tr>';
                  }
              }
          }

?>
