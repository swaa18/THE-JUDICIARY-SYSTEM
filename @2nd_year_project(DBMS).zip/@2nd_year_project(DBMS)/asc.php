<html>
<body background="back4.jpg">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "court system";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if($_SERVER["REQUEST_METHOD"]=="POST")
{

$sql = "SELECT lname,dob,contact,laddress,eid,pending,type FROM lawyer order by pending";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	 		       echo "<br><h1 align='center'><B><I><font size=450px>LAWYER STATUS</font></I></B></h1>";
echo "<p><table border='1'color='blue' align='center' style='border-collapse:�collapse'>";
echo "<tr><th>LAWYER NAME</th><th>DATE OF BIRTH</th><th>CONTACT</th><th>LAWYER ADDRESS</th><th>EMAIL ID</th><th>PENDING</th><th> CASE TYPE</th></tr>";
    while($row = $result->fetch_assoc()) {
         echo "<tr><td>".$row["lname"]."</td><td>".$row["dob"]."</td><td>".$row["contact"]."</td><td>".$row["laddress"]."</td><td>".$row["eid"]."</td><td>".$row["pending"]."</td><td>" .$row["type"]."</td></tr> <br>";	}
echo "</table></p>";
						 } else {
    echo "0 results";
}
}
mysqli_close($conn);




//header("location: select data.php");
?>
</body>
</html>