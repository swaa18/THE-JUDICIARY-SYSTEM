<html>
<body background="back4.jpg">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "court system";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$sql = "SELECT caseno, type,hdate, sdate, applicant.aname,applicant.aaddress, accused.accname,accused.accaddress,jname FROM cases,applicant,accused,judge where cases.aid=applicant.aid and cases.accid=accused.accid and cases.jid=judge.jid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	 
    while($row = $result->fetch_assoc()) {
		if($row["hdate"]== date("Y-m-d"))
		{       echo "<h1 align='center'><B><I><font size=450px>CAUSELIST</font></I></B><h1><br>";
                        
			echo "<br><br><br><table border='4'color='blue' align='center' style='border-collapse: collapse'><tr>";
        echo "<td>CASE TYPE:</td> <TD>" . $row["type"]. "</TD></TR><TR><TD>START DATE:</td> <TD> " . $row["sdate"]. " </TD></TR></table><br><table border='4' align='center'><TR><TD>APPLICANT NAME: </td> <TD>". $row["aname"]." </TD></TR><TR><TD>APPLICANT ADDRESS: </td> <TD>". $row["aaddress"].  " </TD></TR></table><br><table border='4' align='center'><TR><TD>ACCUSED NAME: </td> <TD>". $row["accname"]. " </TD></TR><TR><TD>ACCUSED ADDRESS: </td> <TD>". $row["accaddress"]."</td></tr></table><br>";
		echo "<table border='4' align='center'><tr><td>JUDGE NAME:</td> <TD>" . $row["jname"]. "</td></tr></table>";
		}
    }
} else {
    echo "0 results";
}
}
mysqli_close($conn);




//header("location: select data.php");
?>
</body>
</html>