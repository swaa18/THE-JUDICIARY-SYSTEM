<html>
<head>
<title>case status by case no</title>
<style>
div {
    background-color: lightgrey;
    width: 300px;
    border: 25px solid green;
    padding: 25px;
    margin: auto;
}
body {
    background-image: url("Supreme Court.jpg");
 background-repeat: no-repeat;
background-size:cover;
background-position:center center;
}
</style>
</head>
<body bgcolor="cyan" align="center">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "court system";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$rr=$_POST["case"];

$sql = "SELECT caseno, type, sdate, applicant.aname,applicant.aaddress, accused.accname,accused.accaddress FROM cases,applicant,accused where cases.aid=applicant.aid and cases.accid=accused.accid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	 
    while($row = $result->fetch_assoc()) {
		if($rr==$row["caseno"])
		{
        echo "id: " . $row["type"]. " - Name: " . $row["sdate"]. " " . $row["aname"]. "<br>";
		}
    }
} else {
    echo "0 results";
}
}
mysqli_close($conn);




//header("location: select data.php");
?>
<h1><B><I><U><font color="black">CASE STATUS:<br>SEARCH BY CASE NUMBER</U></I></B></h1>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<div>
<form method="post">
CASE NO:
<input type="text" name="case">
<br><br>

<input type="submit" value="search">
<br>
</form></div>
</body>
</html>