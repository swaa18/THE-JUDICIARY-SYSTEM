<html>
<body background="dates3.jpg">
<?php
$id=$_GET['id'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "court system";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql="select * from lawyer where lid=".$id;
$result=mysqli_query($conn,$sql);
//var_dump($result);
while($row=mysqli_fetch_assoc($result))
{
	echo "<h1 align='center'><B><I><font size=450px>DETAILS</font></I></B><h1><br>";
	echo "<br><br><br><table border='4' align='center' style='border-collapse: collapse'><tr>";
        echo "<td>LAWYER NAME:</td> <TD>" . $row["lname"]. "</TD></TR><TR><TD>DOB:</td> <TD> " . $row["dob"]. " </TD></TR></table><br><table border='4' align='center'><TR><TD>CONTACT NO: </td> <TD>". $row["contact"]." </TD></TR><TR><TD> ADDRESS: </td> <TD>". $row["laddress"].  " </TD></TR></table><br><table border='4' align='center'><TR><TD>EMAIL ID: </td> <TD>". $row["eid"]. " </TD></TR><TR><TD>CASE TYPE: </td> <TD>". $row["type"]."</td></tr></table><br>";
		echo "<table border='4' align='center'><tr><td>CASES UNDERTAKEN:</td> <TD>" . $row["fought"]. "</td></tr><tr><td>CASES WON:</td> <TD>" . $row["won"]. "</td></tr><tr><td>CASES PENDING:</td> <TD>" . $row["pending"]. "</td></tr></table>";

}

?>
</body>
</html>